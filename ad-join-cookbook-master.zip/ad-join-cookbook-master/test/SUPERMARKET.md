The command to upload to the chef supermarket
    
    CHEF_ENV=spuder knife cookbook site share "ad-join" "Operating Systems & Virtualization" -z --dry-run
